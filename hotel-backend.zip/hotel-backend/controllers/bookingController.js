const Booking = require("../models/Booking");

// ✅ Create Booking (Client)
const createBooking = async (req, res) => {
  try {
    const { room, checkInDate, checkOutDate, totalAmount } = req.body;

    if (!room || !checkInDate || !checkOutDate || !totalAmount) {
      return res.status(400).json({ message: "Please fill all booking details" });
    }

    const booking = await Booking.create({
      user: req.user._id,
      room,
      checkInDate,
      checkOutDate,
      totalAmount,
    });

    res.status(201).json({
      success: true,
      message: "Room booked successfully",
      booking,
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Get My Bookings (Client)
const getMyBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id })
      .populate("room")
      .populate("user", "name email");

    res.json({
      success: true,
      bookings,
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ✅ Get All Bookings (Admin)
const getAllBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("room")
      .populate("user", "name email");

    res.json({
      success: true,
      bookings,
    });

  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

module.exports = {
  createBooking,
  getMyBookings,
  getAllBookings,
};