const Room = require("../models/Room");

// Get all rooms
exports.getRooms = async (req, res) => {
  const rooms = await Room.find();
  res.json(rooms);
};

// Add room (Admin)
exports.createRoom = async (req, res) => {
  const { roomNumber, type, price } = req.body;
  const roomExists = await Room.findOne({ roomNumber });
  if (roomExists) return res.status(400).json({ message: "Room already exists" });

  const room = await Room.create({ roomNumber, type, price });
  res.status(201).json(room);
};

// Update room (Admin)
exports.updateRoom = async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) return res.status(404).json({ message: "Room not found" });

  Object.assign(room, req.body);
  await room.save();
  res.json(room);
};

// Delete room (Admin)
exports.deleteRoom = async (req, res) => {
  const room = await Room.findById(req.params.id);
  if (!room) return res.status(404).json({ message: "Room not found" });

  await room.remove();
  res.json({ message: "Room deleted" });
};