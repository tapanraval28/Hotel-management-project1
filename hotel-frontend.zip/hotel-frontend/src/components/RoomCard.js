import React from "react";
import { Link } from "react-router-dom";

function RoomCard({ title, price, image, details }) {
  return (

    <div className="col-lg-4 col-md-6 col-12 mb-4">

      <div className="card shadow h-100">

        <img
          src={image}
          className="card-img-top"
          alt={title}
          style={{ height: "220px", objectFit: "cover" }}
        />

        <div className="card-body text-center">

          <h5 className="card-title">
            {title}
          </h5>

          <p className="card-text">
            Price: ₹{price} / Night
          </p>

          <div className="d-flex justify-content-center">

            <button className="btn btn-primary">
              Book Now
            </button>

            <Link to={details} className="btn btn-secondary ms-2">
              View Details
            </Link>

          </div>

        </div>

      </div>

    </div>

  );
}

export default RoomCard;