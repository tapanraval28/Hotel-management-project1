import React, { useState, useEffect } from "react";

function BackToTop() {

  const [show, setShow] = useState(false);

  useEffect(() => {

    window.addEventListener("scroll", () => {

      if (window.scrollY > 300) {
        setShow(true);
      } else {
        setShow(false);
      }

    });

  }, []);

  const scrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (

    show && (
      <button
        onClick={scrollTop}
        style={{
          position: "fixed",
          bottom: "30px",
          right: "30px",
          padding: "10px 15px",
          background: "black",
          color: "white",
          border: "none",
          borderRadius: "5px"
        }}
      >
        ↑ Top
      </button>
    )

  );
}

export default BackToTop;