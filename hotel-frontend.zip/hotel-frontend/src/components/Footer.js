import React from "react";
import { Link } from "react-router-dom";

function Footer() {
  return (

    <footer className="bg-dark text-light mt-5">

      <div className="container py-5">

        <div className="row">

          {/* Hotel Info */}
          <div className="col-md-4 mb-4">
            <h5 className="mb-3">Green Valley Resort</h5>
            <p>
              Experience luxury and comfort with our premium rooms,
              world-class service, and unforgettable hospitality.
            </p>
          </div>

          {/* Quick Links */}
          <div className="col-md-4 mb-4">
            <h5 className="mb-3">Quick Links</h5>

            <ul className="list-unstyled">

              <li>
                <Link to="/" className="text-light text-decoration-none">Home</Link>
              </li>

              <li>
                <Link to="/rooms" className="text-light text-decoration-none">Rooms</Link>
              </li>

              <li>
                <Link to="/booking" className="text-light text-decoration-none">Booking</Link>
              </li>

              <li>
                <Link to="/contact" className="text-light text-decoration-none">Contact</Link>
              </li>

              <li>
                <Link to="/about" className="text-light text-decoration-none">About</Link>
              </li>

            </ul>

          </div>

          {/* Contact Info */}
          <div className="col-md-4 mb-4">
            <h5 className="mb-3">Contact Us</h5>

            <p className="mb-1">📧 hotel@email.com</p>
            <p className="mb-1">📞 +91 9876543210</p>
            <p>📍 Surat, India</p>

          </div>

        </div>

      </div>

      {/* Bottom Footer */}
      <div className="text-center bg-secondary py-3">
        <p className="mb-0">
          © 2026 Hotel Management System | All Rights Reserved
        </p>
      </div>

    </footer>

  );
}

export default Footer;