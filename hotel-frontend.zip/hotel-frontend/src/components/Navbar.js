import React from "react";
import { NavLink, Link, useNavigate } from "react-router-dom";

function Navbar() {

  const navigate = useNavigate();
  const token = localStorage.getItem("token");

  const handleLogout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">

        <NavLink className="navbar-brand" to="/">
          Green Valley Resort
        </NavLink>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#menu"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="menu">

          <ul className="navbar-nav ms-auto">

            <li className="nav-item">
              <NavLink className="nav-link" to="/">Home</NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/about">About</NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/rooms">Rooms</NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/services">Services</NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/gallery">Gallery</NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/booking">Booking</NavLink>
            </li>

            <li className="nav-item">
              <NavLink className="nav-link" to="/contact">Contact</NavLink>
            </li>

          </ul>

          {/* Login / Logout Section */}
          <div className="ms-3">
            {!token ? (
              <>
                <Link to="/login" className="btn btn-primary me-2">
                  Login
                </Link>

                <Link to="/signup" className="btn btn-success">
                  Signup
                </Link>
              </>
            ) : (
              <button onClick={handleLogout} className="btn btn-danger">
                Logout
              </button>
            )}
          </div>

        </div>
      </div>
    </nav>
  );
}

export default Navbar;