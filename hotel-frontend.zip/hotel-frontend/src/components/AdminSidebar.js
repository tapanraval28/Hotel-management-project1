import React from "react";
import { Link } from "react-router-dom";
import { FaTachometerAlt, FaBed, FaCalendarCheck, FaUsers, FaPlus, FaChartBar, FaCog, FaSignOutAlt } from "react-icons/fa";

function AdminSidebar() {
  return (

    <div className="admin-sidebar">

      <h3 className="sidebar-title">Admin Panel</h3>

      <ul>

        <li>
          <Link to="/admin/dashboard">
            <FaTachometerAlt /> Dashboard
          </Link>
        </li>

        <li>
          <Link to="/admin/rooms">
            <FaBed /> Manage Rooms
          </Link>
        </li>

        <li>
          <Link to="/admin/bookings">
            <FaCalendarCheck /> Manage Bookings
          </Link>
        </li>

        <li>
          <Link to="/admin/users">
            <FaUsers /> Manage Users
          </Link>
        </li>

        <li>
          <Link to="/admin/add-room">
            <FaPlus /> Add Room
          </Link>
        </li>

        <li>
          <Link to="/admin/reports">
            <FaChartBar /> Reports
          </Link>
        </li>

        <li>
          <Link to="/admin/settings">
            <FaCog /> Settings
          </Link>
        </li>

        <li>
          <Link to="/">
            <FaSignOutAlt /> Logout
          </Link>
        </li>

      </ul>

    </div>

  );
}

export default AdminSidebar;