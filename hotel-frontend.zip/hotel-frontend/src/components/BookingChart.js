import React from "react";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

function BookingChart() {

  const data = {
    labels: ["Jan", "Feb", "Mar", "Apr", "May"],
    datasets: [
      {
        label: "Room Bookings",
        data: [5, 7, 3, 9, 6],
        backgroundColor: "#0d6efd"
      }
    ]
  };

  return (
    <div className="card mt-4">
      <div className="card-body">
        <h5 className="text-center">Booking Statistics</h5>
        <Bar data={data} />
      </div>
    </div>
  );
}

export default BookingChart;