import React from "react";
import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";

import "./css/style.css";

import Navbar from "./components/Navbar";
import Footer from "./components/Footer";
import BackToTop from "./components/BackToTop";

import Home from "./pages/Home";
import About from "./pages/About";
import Rooms from "./pages/Rooms";
import Services from "./pages/Services";
import Gallery from "./pages/Gallery";
import RoomDetails from "./pages/RoomDetails";
import Booking from "./pages/Booking";
import Contact from "./pages/Contact";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Logout from "./pages/Logout";

import SingleRoom from "./pages/SingleRoom";
import DoubleRoom from "./pages/DoubleRoom";
import DeluxeRoom from "./pages/DeluxeRoom";
import SuiteRoom from "./pages/SuiteRoom";
import FamilyRoom from "./pages/FamilyRoom";
import TwinRoom from "./pages/TwinRoom";


import AdminLogin from "./pages/admin/AdminLogin";
import AdminDashboard from "./pages/admin/AdminDashboard";
import ManageRooms from "./pages/admin/ManageRooms";
import ManageBookings from "./pages/admin/ManageBookings";
import ManageUsers from "./pages/admin/ManageUsers";
import AddRoom from "./pages/admin/AddRoom";
import Reports from "./pages/admin/Reports";
import Settings from "./pages/admin/Settings";


function Layout() {

  const location = useLocation();

  const isAdminPage = location.pathname.includes("/admin");

  return (
    <>

      {/* Navbar only for user pages */}
      {!isAdminPage && <Navbar />}

      <Routes>

        {/* User Pages */}

        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/rooms" element={<Rooms />} />
        <Route path="/services" element={<Services />} />
        <Route path="/gallery" element={<Gallery />} />
        <Route path="/room-details" element={<RoomDetails />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login />} />
<Route path="/signup" element={<Signup />} />
<Route path="/logout" element={<Logout />} />

        <Route path="/single-room" element={<SingleRoom />} />
        <Route path="/double-room" element={<DoubleRoom />} />
        <Route path="/deluxe-room" element={<DeluxeRoom />} />
        <Route path="/suite-room" element={<SuiteRoom />} />
        <Route path="/family-room" element={<FamilyRoom />} />
        <Route path="/twin-room" element={<TwinRoom />} />

        {/* Admin Pages */}

        <Route path="/admin" element={<AdminLogin />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/rooms" element={<ManageRooms />} />
        <Route path="/admin/bookings" element={<ManageBookings />} />
        <Route path="/admin/users" element={<ManageUsers />} />
<Route path="/admin/add-room" element={<AddRoom />} />
<Route path="/admin/reports" element={<Reports />} />
<Route path="/admin/settings" element={<Settings />} />

      </Routes>

      {/* Footer only for user pages */}
      {!isAdminPage && <Footer />}
      {!isAdminPage && <BackToTop />}

    </>
  );
}

function App() {
  return (
    <Router>
      <Layout />
    </Router>
  );
}

export default App;