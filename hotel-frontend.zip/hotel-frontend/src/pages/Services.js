import React from "react";

function Services() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-5">
        Our Premium Services
      </h2>

      <div className="row text-center">

        <div className="col-md-4 mb-4">
          <div className="card shadow border-0 h-100">
            <img
              src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0"
              className="card-img-top"
              style={{height:"220px", objectFit:"cover"}}
              alt="restaurant"
            />
            <div className="card-body">
              <h4>Restaurant</h4>
              <p>
                Enjoy delicious international cuisine prepared by our expert chefs.
              </p>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow border-0 h-100">
            <img
              src="https://images.unsplash.com/photo-1540555700478-4be289fbecef"
              className="card-img-top"
              style={{height:"220px", objectFit:"cover"}}
              alt="spa"
            />
            <div className="card-body">
              <h4>Spa & Wellness</h4>
              <p>
                Relax your body and mind with our luxury spa treatments.
              </p>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow border-0 h-100">
            <img
              src="https://images.unsplash.com/photo-1575429198097-0414ec08e8cd"
              className="card-img-top"
              style={{height:"220px", objectFit:"cover"}}
              alt="pool"
            />
            <div className="card-body">
              <h4>Swimming Pool</h4>
              <p>
                Enjoy our beautiful outdoor swimming pool with relaxing views.
              </p>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow border-0 h-100">
           <img
  src="https://images.unsplash.com/photo-1582719508461-905c673771fd"
  className="card-img-top"
  style={{height:"220px", objectFit:"cover"}}
  alt="room service"
/>
            <div className="card-body">
              <h4>Room Service</h4>
              <p>
                24/7 room service available for your comfort and convenience.
              </p>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow border-0 h-100">
            <img
              src="https://images.unsplash.com/photo-1519389950473-47ba0277781c"
              className="card-img-top"
              style={{height:"220px", objectFit:"cover"}}
              alt="wifi"
            />
            <div className="card-body">
              <h4>Free WiFi</h4>
              <p>
                High-speed WiFi available in every room and public area.
              </p>
            </div>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow border-0 h-100">
            <img
              src="https://images.unsplash.com/photo-1506521781263-d8422e82f27a"
              className="card-img-top"
              style={{height:"220px", objectFit:"cover"}}
              alt="parking"
            />
            <div className="card-body">
              <h4>Parking</h4>
              <p>
                Spacious and secure parking area available for all guests.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>

  );
}

export default Services;