import React from "react";
import { useNavigate } from "react-router-dom";

function Booking() {

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    // booking logic here

    navigate("/booking-success");
  };

  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Book Your Room
      </h2>

      <div className="row justify-content-center">

        <div className="col-md-6">

          <form onSubmit={handleSubmit} className="shadow p-4 rounded">

            {/* Name */}

            <div className="mb-3">
              <label className="form-label">Full Name</label>
              <input 
              type="text"
              className="form-control"
              placeholder="Enter your full name"
              required
              />
            </div>

            {/* Email */}

            <div className="mb-3">
              <label className="form-label">Email Address</label>
              <input
              type="email"
              className="form-control"
              placeholder="Enter your email"
              required
              />
            </div>

            {/* Phone */}

            <div className="mb-3">
              <label className="form-label">Phone Number</label>
              <input
              type="tel"
              className="form-control"
              placeholder="Enter phone number"
              required
              />
            </div>

            {/* Check In */}

            <div className="mb-3">
              <label className="form-label">Check-In Date</label>
              <input
              type="date"
              className="form-control"
              required
              />
            </div>

            {/* Check Out */}

            <div className="mb-3">
              <label className="form-label">Check-Out Date</label>
              <input
              type="date"
              className="form-control"
              required
              />
            </div>

            {/* Guests */}

            <div className="mb-3">
              <label className="form-label">Number of Guests</label>
              <select className="form-control">
                <option>1 Guest</option>
                <option>2 Guests</option>
                <option>3 Guests</option>
                <option>4 Guests</option>
              </select>
            </div>

            {/* Room Type */}

            <div className="mb-3">
              <label className="form-label">Room Type</label>

              <select className="form-control">

                <option>Single Room</option>
                <option>Double Room</option>
                <option>Deluxe Room</option>
                <option>Suite Room</option>
                <option>Family Room</option>
                <option>Twin Room</option>

              </select>

            </div>

            {/* Message */}

            <div className="mb-3">
              <label className="form-label">Special Requests</label>

              <textarea
              className="form-control"
              rows="3"
              placeholder="Any special requests..."
              ></textarea>
            </div>

            {/* Button */}

            <button type="submit" className="btn btn-primary w-100">
              Confirm Booking
            </button>

          </form>

        </div>

      </div>

    </div>

  );
}

export default Booking;