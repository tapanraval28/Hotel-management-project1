import React from "react";

function Gallery() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Hotel Gallery
      </h2>

      <div className="row g-4">

        <div className="col-md-4 text-center">
          <img
          src="https://images.unsplash.com/photo-1566073771259-6a8506099945"
          className="img-fluid rounded shadow"
          alt="hotel exterior"
          style={{ height: "250px", width: "100%", objectFit: "cover" }}
          />
          <p className="mt-2 fw-semibold">Hotel Exterior View</p>
        </div>

        <div className="col-md-4 text-center">
          <img
          src="https://images.unsplash.com/photo-1582719508461-905c673771fd"
          className="img-fluid rounded shadow"
          alt="deluxe room"
          style={{ height: "250px", width: "100%", objectFit: "cover" }}
          />
          <p className="mt-2 fw-semibold">Deluxe Room Interior</p>
        </div>

        <div className="col-md-4 text-center">
          <img
          src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb"
          className="img-fluid rounded shadow"
          alt="hotel pool"
          style={{ height: "250px", width: "100%", objectFit: "cover" }}
          />
          <p className="mt-2 fw-semibold">Swimming Pool Area</p>
        </div>

        <div className="col-md-4 text-center">
          <img
          src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85"
          className="img-fluid rounded shadow"
          alt="single room"
          style={{ height: "250px", width: "100%", objectFit: "cover" }}
          />
          <p className="mt-2 fw-semibold">Single Room</p>
        </div>

        <div className="col-md-4 text-center">
          <img
          src="https://images.unsplash.com/photo-1590490360182-c33d57733427"
          className="img-fluid rounded shadow"
          alt="double room"
          style={{ height: "250px", width: "100%", objectFit: "cover" }}
          />
          <p className="mt-2 fw-semibold">Double Room</p>
        </div>

        <div className="col-md-4 text-center">
          <img
          src="https://images.unsplash.com/photo-1551882547-ff40c63fe5fa"
          className="img-fluid rounded shadow"
          alt="hotel restaurant"
          style={{ height: "250px", width: "100%", objectFit: "cover" }}
          />
          <p className="mt-2 fw-semibold">Green Valley Hotel</p>
        </div>

      </div>

    </div>

  );
}

export default Gallery;