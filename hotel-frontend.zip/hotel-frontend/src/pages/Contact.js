import React from "react";

function Contact() {
  return (
    <div className="container mt-5">

      {/* Page Title */}
      <h1 className="text-center mb-5">Contact Our Hotel</h1>

      <div className="row">

        {/* Contact Information */}
        <div className="col-md-4 mb-4">
          <div className="card shadow text-center p-4">
            <h4>📞 Phone</h4>
            <p className="text-muted">+91 9876543210</p>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow text-center p-4">
            <h4>📧 Email</h4>
            <p className="text-muted">hotel@email.com</p>
          </div>
        </div>

        <div className="col-md-4 mb-4">
          <div className="card shadow text-center p-4">
            <h4>📍 Location</h4>
            <p className="text-muted">Surat, Gujarat, India</p>
          </div>
        </div>

      </div>

      {/* Contact Form */}
      <div className="row mt-5">

        <div className="col-md-6">
          <h3 className="mb-4">Send Us a Message</h3>

          <form>

            <div className="mb-3">
              <label className="form-label">Your Name</label>
              <input
                type="text"
                className="form-control"
                placeholder="Enter your name"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Email</label>
              <input
                type="email"
                className="form-control"
                placeholder="Enter your email"
              />
            </div>

            <div className="mb-3">
              <label className="form-label">Message</label>
              <textarea
                className="form-control"
                rows="4"
                placeholder="Write your message"
              ></textarea>
            </div>

            <button className="btn btn-primary w-100">
              Send Message
            </button>

          </form>
        </div>

      </div>

    </div>
  );
}

export default Contact;