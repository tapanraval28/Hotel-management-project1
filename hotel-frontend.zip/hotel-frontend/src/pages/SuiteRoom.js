import React from "react";
import { Link } from "react-router-dom";

function SuiteRoom() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Suite Room
      </h2>

      <div className="row">

        <div className="col-md-6">

          <img
          src="https://images.unsplash.com/photo-1566665797739-1674de7a421a"
          className="img-fluid rounded shadow"
          alt="suite room"
          />

        </div>

        <div className="col-md-6">

          <h4 className="text-primary">
            Price: ₹5000 / Night
          </h4>

          <p>
          Our Suite Room offers the ultimate luxury experience
          with a spacious bedroom and living area. Perfect for
          guests who want premium comfort and privacy.
          </p>

          <h5 className="mt-3">Room Facilities</h5>

          <ul>
            <li>King Size Bed</li>
            <li>Separate Living Area</li>
            <li>Free High-Speed WiFi</li>
            <li>Air Conditioning</li>
            <li>Smart TV</li>
            <li>Mini Refrigerator</li>
            <li>Luxury Bathroom</li>
            <li>24/7 Room Service</li>
          </ul>

          <Link to="/booking" className="btn btn-primary btn-lg mt-3">
            Book Now
          </Link>

        </div>

      </div>

    </div>

  );
}

export default SuiteRoom;