import React from "react";
import { Link } from "react-router-dom";

function FamilyRoom() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Family Room
      </h2>

      <div className="row">

        <div className="col-md-6">

          <img
          src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
          className="img-fluid rounded shadow"
          alt="family room"
          />

        </div>

        <div className="col-md-6">

          <h4 className="text-primary">
            Price: ₹4200 / Night
          </h4>

          <p>
          Our Family Room is specially designed for families
          who need extra space and comfort. It includes multiple
          beds and modern facilities for a relaxing stay.
          </p>

          <h5 className="mt-3">Room Facilities</h5>

          <ul>
            <li>2 Large Beds</li>
            <li>Free High-Speed WiFi</li>
            <li>Air Conditioning</li>
            <li>Smart TV</li>
            <li>Wardrobe</li>
            <li>Private Bathroom</li>
            <li>24/7 Room Service</li>
          </ul>

          <Link to="/booking" className="btn btn-primary btn-lg mt-3">
            Book Now
          </Link>

        </div>

      </div>

    </div>

  );
}

export default FamilyRoom;