import React from "react";
import { Link } from "react-router-dom";

function DoubleRoom() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Double Room
      </h2>

      <div className="row">

        <div className="col-md-6">

          <img
          src="https://images.unsplash.com/photo-1590490360182-c33d57733427"
          className="img-fluid rounded shadow"
          alt="double room"
          />

        </div>

        <div className="col-md-6">

          <h4 className="text-primary">
            Price: ₹2000 / Night
          </h4>

          <p>
          Our Double Room is perfect for couples or two guests looking for a 
          comfortable and relaxing stay. The room is designed with modern 
          interiors and provides a cozy environment for both leisure and 
          business travelers.
          </p>

          <h5 className="mt-3">Room Facilities</h5>

          <ul>
            <li>Comfortable Double Bed</li>
            <li>Free High-Speed WiFi</li>
            <li>Air Conditioning</li>
            <li>LED TV with Entertainment Channels</li>
            <li>Work Desk</li>
            <li>Private Bathroom</li>
            <li>24/7 Room Service</li>
            <li>Complimentary Drinking Water</li>
          </ul>

          <Link to="/booking" className="btn btn-primary btn-lg mt-3">
            Book Now
          </Link>

        </div>

      </div>

    </div>

  );
}

export default DoubleRoom;