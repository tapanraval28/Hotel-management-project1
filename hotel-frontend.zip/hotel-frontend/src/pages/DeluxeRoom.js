import React from "react";

function DeluxeRoom() {
  return (
    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Deluxe Room
      </h2>

      <div className="row">

        <div className="col-md-6">
          <img
            src="https://images.unsplash.com/photo-1582719508461-905c673771fd"
            className="img-fluid rounded shadow"
            alt="Deluxe Room"
          />
        </div>

        <div className="col-md-6">

          <h4 className="text-primary">
            Price: ₹3500 / Night
          </h4>

          <p>
            Our Deluxe Room offers luxury and comfort with modern
            facilities. It is perfect for guests who want a spacious
            room with premium services and a relaxing atmosphere.
          </p>

          <h5 className="mt-3">Room Facilities</h5>

          <ul>
            <li>King Size Bed</li>
            <li>Free High-Speed WiFi</li>
            <li>Air Conditioning</li>
            <li>Smart TV</li>
            <li>Mini Refrigerator</li>
            <li>24/7 Room Service</li>
            <li>Luxury Bathroom</li>
          </ul>

          <button className="btn btn-primary mt-3">
            Book Now
          </button>

        </div>

      </div>

    </div>
  );
}

export default DeluxeRoom;