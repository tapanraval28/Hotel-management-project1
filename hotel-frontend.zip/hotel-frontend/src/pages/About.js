import React from "react";

function About() {
  return (
    <div className="container mt-5">

      {/* Title */}
      <h1 className="text-center mb-4">About Our Hotel</h1>

      {/* Main Section */}
      <div className="row align-items-center mb-5">

        <div className="col-md-6">
          <img
            src="https://images.unsplash.com/photo-1551882547-ff40c63fe5fa"
            className="img-fluid rounded shadow"
            alt="hotel"
          />
        </div>

        <div className="col-md-6">
          <h3>Welcome to Our Luxury Hotel</h3>

          <p>
            Our hotel provides a comfortable and relaxing environment
            for travelers, families, and business guests.
          </p>

          <p>
            Located in the beautiful city of Surat, our hotel offers
            modern rooms, delicious food, and professional service
            at affordable prices.
          </p>

          <p>
            Whether you are visiting for business or vacation,
            we ensure that your stay is comfortable and enjoyable.
          </p>
        </div>

      </div>

      {/* Hotel Features */}
      <div className="text-center mb-5">

        <h2 className="mb-4">Our Facilities</h2>

        <div className="row">

          <div className="col-md-3">
            <div className="card shadow p-3">
              <h5>🏊 Swimming Pool</h5>
              <p>Relax and enjoy our clean and modern pool.</p>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card shadow p-3">
              <h5>📶 Free WiFi</h5>
              <p>High-speed internet available in all rooms.</p>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card shadow p-3">
              <h5>🍽 Restaurant</h5>
              <p>Delicious meals and beverages for guests.</p>
            </div>
          </div>

          <div className="col-md-3">
            <div className="card shadow p-3">
              <h5>🚗 Parking</h5>
              <p>Safe and secure parking for visitors.</p>
            </div>
          </div>

        </div>
      </div>

      {/* Gallery Section */}
      <div className="text-center mb-5">

        <h2 className="mb-4">Hotel Gallery</h2>

        <div className="row">

          <div className="col-md-4">
            <img
              src="https://images.unsplash.com/photo-1566073771259-6a8506099945"
              className="img-fluid rounded shadow mb-3"
              alt="Hotel Lobby"
              style={{ height: "250px", width: "100%", objectFit: "cover" }}
            />
            <p className="fw-semibold">Hotel Lobby</p>
          </div>

          <div className="col-md-4">
            <img
              src="https://images.unsplash.com/photo-1582719478250-c89cae4dc85b"
              className="img-fluid rounded shadow mb-3"
              alt="Deluxe Room"
              style={{ height: "250px", width: "100%", objectFit: "cover" }}
            />
            <p className="fw-semibold">Deluxe Room</p>
          </div>

          <div className="col-md-4">
            <img
              src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461"
              className="img-fluid rounded shadow mb-3"
              alt="Luxury Room"
              style={{ height: "250px", width: "100%", objectFit: "cover" }}
            />
            <p className="fw-semibold">Luxury Room</p>
          </div>

        </div>
      </div>

      {/* Testimonials Section */}
      <div className="mt-5">
        <h2 className="text-center mb-4">What Our Guests Say</h2>

        <div className="row">

          <div className="col-md-4">
            <div className="card p-3 shadow-sm">
              <p>
                "Amazing experience! The rooms were clean and the service was excellent."
              </p>
              <h6 className="mt-3 text-end">– Rahul Sharma</h6>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card p-3 shadow-sm">
              <p>
                "Best hotel stay ever. Friendly staff and beautiful ambience."
              </p>
              <h6 className="mt-3 text-end">– Priya Patel</h6>
            </div>
          </div>

          <div className="col-md-4">
            <div className="card p-3 shadow-sm">
              <p>
                "Comfortable rooms, great food, and excellent location."
              </p>
              <h6 className="mt-3 text-end">– Arjun Mehta</h6>
            </div>
          </div>

        </div>
      </div>

    </div>
  );
}

export default About;