import React from "react";
import RoomCard from "../components/RoomCard";

function Rooms() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-3">
        Our Rooms
      </h2>

      <p className="text-center mb-5">
        We offer Single, Double, Deluxe, Suite, Family and Twin rooms with modern facilities.
      </p>

      <div className="row">

        <RoomCard
        title="Single Room"
        price="1200"
        image="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85"
        details="/single-room"
        />

        <RoomCard
        title="Double Room"
        price="2000"
        image="https://images.unsplash.com/photo-1590490360182-c33d57733427"
        details="/double-room"
        />

        <RoomCard
        title="Deluxe Room"
        price="3500"
        image="https://images.unsplash.com/photo-1582719508461-905c673771fd"
        details="/deluxe-room"
        />

        <RoomCard
        title="Suite Room"
        price="5000"
        image="https://images.unsplash.com/photo-1566665797739-1674de7a421a"
        details="/suite-room"
        />

        <RoomCard
        title="Family Room"
        price="4200"
        image="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
        details="/family-room"
        />

        <RoomCard
        title="Twin Room"
        price="2800"
        image="https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf"
        details="/twin-room"
        />

      </div>

    </div>

  );
}

export default Rooms;