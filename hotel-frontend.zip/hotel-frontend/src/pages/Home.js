import React from "react";
import { Link } from "react-router-dom";
import RoomCard from "../components/RoomCard";

function Home() {
  return (

    <div>

      {/* HERO SECTION */}

      <div className="container mt-5">

        <div className="row align-items-center">

          <div className="col-md-6">

            <h1 className="fw-bold">
              Welcome to <span className="text-success">Green Valley Resort</span>
            </h1>

            <p className="lead">
              Experience comfort, elegance, and world-class hospitality at 
              <strong> Green Valley Resort</strong>. 
              Book the best rooms at affordable prices and enjoy a relaxing stay.
            </p>

            <Link to="/rooms" className="btn btn-primary btn-lg mt-3">
              Explore Rooms
            </Link>

          </div>

          <div className="col-md-6">

            <img
              src="https://images.unsplash.com/photo-1566073771259-6a8506099945"
              className="img-fluid rounded shadow"
              alt="hotel"
            />

          </div>

        </div>

      </div>


      {/* ROOMS SECTION */}

      <div className="container mt-5">

        <h2 className="text-center mb-4">
          Our Rooms
        </h2>

        <div className="row">

          <RoomCard
            title="Single Room"
            price="1200"
            image="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85"
          />

          <RoomCard
            title="Double Room"
            price="2000"
            image="https://images.unsplash.com/photo-1590490360182-c33d57733427"
          />

          <RoomCard
            title="Deluxe Room"
            price="3500"
            image="https://images.unsplash.com/photo-1582719508461-905c673771fd"
          />

          <RoomCard
            title="Suite Room"
            price="5000"
            image="https://images.unsplash.com/photo-1566665797739-1674de7a421a"
          />

          <RoomCard
            title="Family Room"
            price="4200"
            image="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
          />

          <RoomCard
            title="Twin Room"
            price="2800"
            image="https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf"
          />

        </div>

      </div>


      {/* FACILITIES SECTION */}

      <div className="container mt-5">

        <h2 className="text-center mb-4">
          Our Facilities
        </h2>

        <div className="row text-center">

          <div className="col-md-4 mb-4">
            <div className="card p-4 shadow border-0">
              <h4>📶 Free WiFi</h4>
              <p>High speed internet available in all rooms.</p>
            </div>
          </div>

          <div className="col-md-4 mb-4">
            <div className="card p-4 shadow border-0">
              <h4>🏊 Swimming Pool</h4>
              <p>Relax and enjoy our beautiful swimming pool.</p>
            </div>
          </div>

          <div className="col-md-4 mb-4">
            <div className="card p-4 shadow border-0">
              <h4>🚗 Free Parking</h4>
              <p>Safe and secure parking available for guests.</p>
            </div>
          </div>

        </div>

      </div>


      {/* TESTIMONIAL SECTION */}

      <div className="container mt-5">

        <h2 className="text-center mb-4">
          What Our Guests Say
        </h2>

        <div className="row text-center">

          <div className="col-md-4 mb-4">
            <div className="card p-3 shadow border-0">
              <h5>Rahul Sharma</h5>
              <p>
                "Amazing hotel! The rooms were very clean and the staff was very friendly."
              </p>
            </div>
          </div>

          <div className="col-md-4 mb-4">
            <div className="card p-3 shadow border-0">
              <h5>Priya Patel</h5>
              <p>
                "Great experience. The swimming pool and food were excellent!"
              </p>
            </div>
          </div>

          <div className="col-md-4 mb-4">
            <div className="card p-3 shadow border-0">
              <h5>Arjun Mehta</h5>
              <p>
                "Best hotel stay I have had in a long time. Highly recommended!"
              </p>
            </div>
          </div>

        </div>

      </div>


      {/* GALLERY SECTION */}

      <div className="container mt-5 mb-5">

        <h2 className="text-center mb-4">
          Hotel Gallery
        </h2>

        <div className="row g-4">

          <div className="col-md-4 text-center">
            <img
              src="https://images.unsplash.com/photo-1578683010236-d716f9a3f461"
              className="img-fluid rounded shadow"
              alt="hotel exterior"
              style={{ height: "250px", width: "100%", objectFit: "cover" }}
            />
            <p className="mt-2 fw-semibold">Hotel Exterior</p>
          </div>

          <div className="col-md-4 text-center">
            <img
              src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
              className="img-fluid rounded shadow"
              alt="family room"
              style={{ height: "250px", width: "100%", objectFit: "cover" }}
            />
            <p className="mt-2 fw-semibold">Family Room</p>
          </div>

          <div className="col-md-4 text-center">
            <img
              src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb"
              className="img-fluid rounded shadow"
              alt="swimming pool"
              style={{ height: "250px", width: "100%", objectFit: "cover" }}
            />
            <p className="mt-2 fw-semibold">Swimming Pool</p>
          </div>

        </div>

      </div>

    </div>

  );
}

export default Home;