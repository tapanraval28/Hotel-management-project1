import React, { useState, useMemo } from "react";
import AdminSidebar from "../../components/AdminSidebar";

function ManageBookings() {
  const [bookings, setBookings] = useState([
    { id: 1, customerName: "Rahul", room: "Deluxe Room", date: "2026-03-15", status: "Pending" },
    { id: 2, customerName: "Priya", room: "Double Room", date: "2026-03-16", status: "Pending" },
  ]);

  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");
  const [form, setForm] = useState({
    customerName: "",
    room: "",
    date: "",
    status: "Pending",
  });
  const [editing, setEditing] = useState(null);
  const [showForm, setShowForm] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const reset = () => {
    setForm({ customerName: "", room: "", date: "", status: "Pending" });
    setEditing(null);
    setShowForm(false);
  };

  const save = (e) => {
    e.preventDefault();

    if (!form.customerName || !form.room || !form.date)
      return alert("Fill all fields");

    if (editing) {
      setBookings((p) =>
        p.map((b) => (b.id === editing.id ? { ...b, ...form } : b))
      );
    } else {
      setBookings((p) => [...p, { id: Date.now(), ...form }]);
    }
    reset();
  };

  const updateStatus = (id, status) => {
    if (!window.confirm("Confirm?")) return;
    setBookings((p) => p.map((b) => (b.id === id ? { ...b, status } : b)));
  };

  const remove = (id) => {
    if (!window.confirm("Delete?")) return;
    setBookings((p) => p.filter((b) => b.id !== id));
  };

  const edit = (b) => {
    setForm(b);
    setEditing(b);
    setShowForm(true);
  };

  const badge = (s) =>
    s === "Approved"
      ? "badge bg-success"
      : s === "Cancelled"
      ? "badge bg-danger"
      : "badge bg-warning text-dark";

  const filtered = useMemo(() => {
    return bookings.filter(
      (b) =>
        b.customerName.toLowerCase().includes(search.toLowerCase()) &&
        (filter === "All" || b.status === filter)
    );
  }, [bookings, search, filter]);

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main">
        <div className="d-flex justify-content-between mb-3">
          <h2>Manage Bookings</h2>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>
            + Add
          </button>
        </div>

        <div className="d-flex mb-3">
          <input
            className="form-control me-2"
            placeholder="Search"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

          <select
            className="form-select"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
          >
            <option>All</option>
            <option>Pending</option>
            <option>Approved</option>
            <option>Cancelled</option>
          </select>
        </div>

        <table className="table table-bordered">
          <thead className="table-dark">
            <tr>
              <th>ID</th>
              <th>Customer</th>
              <th>Room</th>
              <th>Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan="6" className="text-center">
                  No data
                </td>
              </tr>
            ) : (
              filtered.map((b) => (
                <tr key={b.id}>
                  <td>{b.id}</td>
                  <td>{b.customerName}</td>
                  <td>{b.room}</td>
                  <td>{b.date}</td>
                  <td>
                    <span className={badge(b.status)}>{b.status}</span>
                  </td>
                  <td>
                    {b.status === "Pending" && (
                      <>
                        <button
                          className="btn btn-success btn-sm"
                          onClick={() => updateStatus(b.id, "Approved")}
                        >
                          Approve
                        </button>
                        <button
                          className="btn btn-warning btn-sm ms-2"
                          onClick={() => updateStatus(b.id, "Cancelled")}
                        >
                          Cancel
                        </button>
                      </>
                    )}

                    <button
                      className="btn btn-info btn-sm ms-2"
                      onClick={() => edit(b)}
                    >
                      Edit
                    </button>

                    <button
                      className="btn btn-danger btn-sm ms-2"
                      onClick={() => remove(b.id)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>

        {showForm && (
          <div className="card p-4">
            <h5>{editing ? "Edit Booking" : "Add Booking"}</h5>

            <form onSubmit={save}>
              <div className="row">
                <div className="col-md-3">
                  <input
                    name="customerName"
                    className="form-control"
                    placeholder="Customer"
                    value={form.customerName}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-3">
                  <input
                    name="room"
                    className="form-control"
                    placeholder="Room"
                    value={form.room}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-3">
                  <input
                    type="date"
                    name="date"
                    className="form-control"
                    value={form.date}
                    onChange={handleChange}
                  />
                </div>

                <div className="col-md-3">
                  <select
                    name="status"
                    className="form-select"
                    value={form.status}
                    onChange={handleChange}
                  >
                    <option>Pending</option>
                    <option>Approved</option>
                    <option>Cancelled</option>
                  </select>
                </div>
              </div>

              <button className="btn btn-success mt-3">
                {editing ? "Update" : "Save"}
              </button>

              <button
                type="button"
                className="btn btn-secondary mt-3 ms-2"
                onClick={reset}
              >
                Cancel
              </button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}

export default ManageBookings;