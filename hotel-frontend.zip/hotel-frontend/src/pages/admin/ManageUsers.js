import React, { useState } from "react";
import AdminSidebar from "../../components/AdminSidebar";

function ManageUsers() {
  const [users, setUsers] = useState([
    { _id: "1", name: "John Doe", email: "john@email.com" },
    { _id: "2", name: "Jane Smith", email: "jane@email.com" },
    { _id: "3", name: "Mike Ross", email: "mike@email.com" },
  ]);

  const [search, setSearch] = useState("");

  // DELETE USER
  const handleDelete = (id) => {
    if (!window.confirm("Delete this user?")) return;
    setUsers((prev) => prev.filter((u) => u._id !== id));
  };

  // EDIT USER (demo only - alert)
  const handleEdit = (user) => {
    alert(`Edit user: ${user.name}`);
  };

  const filteredUsers = users.filter((u) =>
    u.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2>Manage Users</h2>

          <input
            type="text"
            className="form-control"
            placeholder="Search users..."
            style={{ maxWidth: "250px" }}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="card shadow-sm">
          <div className="card-body p-0">
            <table className="table table-hover mb-0">
              <thead className="table-dark">
                <tr>
                  <th>#ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th className="text-center">Actions</th>
                </tr>
              </thead>

              <tbody>
                {filteredUsers.length > 0 ? (
                  filteredUsers.map((user, index) => (
                    <tr key={user._id}>
                      <td>{index + 1}</td>
                      <td>{user.name}</td>
                      <td>{user.email}</td>

                      <td className="text-center">
                        <button
                          className="btn btn-outline-primary btn-sm me-2"
                          onClick={() => handleEdit(user)}
                        >
                          Edit
                        </button>

                        <button
                          className="btn btn-outline-danger btn-sm"
                          onClick={() => handleDelete(user._id)}
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="text-center py-4 text-muted">
                      No users found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-3 text-muted small">
          Showing {filteredUsers.length} users
        </div>
      </div>
    </div>
  );
}

export default ManageUsers;