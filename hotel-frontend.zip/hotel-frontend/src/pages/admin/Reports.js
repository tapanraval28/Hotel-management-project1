import React from "react";
import AdminSidebar from "../../components/AdminSidebar";

function Reports() {
  // UI-only dummy data
  const stats = [
    {
      title: "Total Revenue",
      value: "₹50,000",
      bg: "bg-info",
    },
    {
      title: "Total Bookings",
      value: "120",
      bg: "bg-success",
    },
    {
      title: "Available Rooms",
      value: "8",
      bg: "bg-warning",
    },
  ];

  const bookings = [
    {
      name: "Rahul Sharma",
      room: "101",
      in: "10 Mar 2026",
      out: "12 Mar 2026",
      status: "Checked In",
    },
    {
      name: "Priya Patel",
      room: "203",
      in: "11 Mar 2026",
      out: "13 Mar 2026",
      status: "Booked",
    },
    {
      name: "Amit Kumar",
      room: "305",
      in: "12 Mar 2026",
      out: "15 Mar 2026",
      status: "Confirmed",
    },
  ];

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2 className="mb-0">Reports</h2>

          <button className="btn btn-primary btn-sm">
            Export Report
          </button>
        </div>

        {/* STATS CARDS */}
        <div className="row mb-4">
          {stats.map((item, index) => (
            <div className="col-md-4" key={index}>
              <div
                className={`card ${item.bg} text-white p-3 shadow-sm`}
                style={{ borderRadius: "12px" }}
              >
                <h6 className="mb-1">{item.title}</h6>
                <h3 className="fw-bold">{item.value}</h3>
              </div>
            </div>
          ))}
        </div>

        {/* BOOKINGS TABLE */}
        <div className="card shadow-sm p-3">
          <div className="d-flex justify-content-between align-items-center mb-2">
            <h5 className="mb-0">Recent Bookings</h5>

            <input
              type="text"
              className="form-control form-control-sm"
              placeholder="Search bookings..."
              style={{ maxWidth: "200px" }}
            />
          </div>

          <div className="table-responsive">
            <table className="table table-hover align-middle">
              <thead className="table-dark">
                <tr>
                  <th>Guest</th>
                  <th>Room</th>
                  <th>Check In</th>
                  <th>Check Out</th>
                  <th>Status</th>
                </tr>
              </thead>

              <tbody>
                {bookings.map((b, index) => (
                  <tr key={index}>
                    <td className="fw-semibold">{b.name}</td>
                    <td>{b.room}</td>
                    <td>{b.in}</td>
                    <td>{b.out}</td>
                    <td>
                      <span
                        className={`badge ${
                          b.status === "Checked In"
                            ? "bg-success"
                            : b.status === "Booked"
                            ? "bg-warning text-dark"
                            : "bg-primary"
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* FOOTER */}
        <div className="mt-3 text-muted small">
          Showing {bookings.length} recent bookings
        </div>
      </div>
    </div>
  );
}

export default Reports;