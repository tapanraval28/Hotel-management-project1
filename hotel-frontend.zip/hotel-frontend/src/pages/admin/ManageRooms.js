import React, { useState } from "react";
import AdminSidebar from "../../components/AdminSidebar";

function ManageRooms() {
  const [rooms, setRooms] = useState([
    { id: 1, number: 101, type: "Single", status: "Available" },
    { id: 2, number: 102, type: "Double", status: "Booked" },
    { id: 3, number: 103, type: "Deluxe", status: "Maintenance" },
  ]);

  const [showForm, setShowForm] = useState(false);
  const [newRoom, setNewRoom] = useState({
    number: "",
    type: "",
    status: "Available",
  });

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this room?")) {
      setRooms(rooms.filter((room) => room.id !== id));
    }
  };

  const handleStatusChange = (id, newStatus) => {
    setRooms(
      rooms.map((room) =>
        room.id === id ? { ...room, status: newStatus } : room
      )
    );
  };

  const handleAddRoom = (e) => {
    e.preventDefault();

    if (!newRoom.number || !newRoom.type) {
      alert("Please fill all fields");
      return;
    }

    const newEntry = {
      id: Date.now(),
      number: newRoom.number,
      type: newRoom.type,
      status: newRoom.status,
    };

    setRooms([...rooms, newEntry]);
    setNewRoom({ number: "", type: "", status: "Available" });
    setShowForm(false);
  };

  const getStatusBadge = (status) => {
    switch (status) {
      case "Available":
        return "badge bg-success";
      case "Booked":
        return "badge bg-danger";
      case "Maintenance":
        return "badge bg-warning text-dark";
      default:
        return "badge bg-secondary";
    }
  };

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main">
        <div className="d-flex justify-content-between align-items-center mb-4">
          <h2>Manage Rooms</h2>
          <button
            className="btn btn-primary"
            onClick={() => setShowForm(!showForm)}
          >
            + Add Room
          </button>
        </div>

        {/* Add Room Form */}
        {showForm && (
          <div className="card p-3 mb-4">
            <form onSubmit={handleAddRoom}>
              <div className="row">
                <div className="col-md-4">
                  <input
                    type="number"
                    placeholder="Room Number"
                    className="form-control"
                    value={newRoom.number}
                    onChange={(e) =>
                      setNewRoom({ ...newRoom, number: e.target.value })
                    }
                  />
                </div>

                <div className="col-md-4">
                  <input
                    type="text"
                    placeholder="Room Type"
                    className="form-control"
                    value={newRoom.type}
                    onChange={(e) =>
                      setNewRoom({ ...newRoom, type: e.target.value })
                    }
                  />
                </div>

                <div className="col-md-4">
                  <select
                    className="form-control"
                    value={newRoom.status}
                    onChange={(e) =>
                      setNewRoom({ ...newRoom, status: e.target.value })
                    }
                  >
                    <option>Available</option>
                    <option>Booked</option>
                    <option>Maintenance</option>
                  </select>
                </div>
              </div>

              <button type="submit" className="btn btn-success mt-3">
                Save Room
              </button>
            </form>
          </div>
        )}

        <table className="table table-bordered table-hover">
          <thead className="table-dark">
            <tr>
              <th>Room Number</th>
              <th>Type</th>
              <th>Status</th>
              <th style={{ width: "250px" }}>Action</th>
            </tr>
          </thead>

          <tbody>
            {rooms.length === 0 ? (
              <tr>
                <td colSpan="4" className="text-center">
                  No rooms available.
                </td>
              </tr>
            ) : (
              rooms.map((room) => (
                <tr key={room.id}>
                  <td>{room.number}</td>
                  <td>{room.type}</td>
                  <td>
                    <span className={getStatusBadge(room.status)}>
                      {room.status}
                    </span>
                  </td>
                  <td>
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={() => handleDelete(room.id)}
                    >
                      Delete
                    </button>

                    <div className="mt-2">
                      <button
                        className="btn btn-success btn-sm me-2"
                        onClick={() =>
                          handleStatusChange(room.id, "Available")
                        }
                      >
                        Set Available
                      </button>

                      <button
                        className="btn btn-secondary btn-sm"
                        onClick={() =>
                          handleStatusChange(room.id, "Maintenance")
                        }
                      >
                        Maintenance
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default ManageRooms;