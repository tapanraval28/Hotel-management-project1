import React, { useState, useEffect } from "react";
import AdminSidebar from "../../components/AdminSidebar";

function AddRoom() {
  const initialState = {
    roomNumber: "",
    name: "",
    type: "Single",
    price: "",
    capacity: 1,
    status: "Available",
    description: "",
    image: null,
  };

  const [roomData, setRoomData] = useState(initialState);
  const [preview, setPreview] = useState(null);
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value, type } = e.target;

    setRoomData((prev) => ({
      ...prev,
      [name]: type === "number" ? Number(value) : value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setMessage({ type: "danger", text: "Only image files allowed" });
      return;
    }

    setRoomData((prev) => ({ ...prev, image: file }));

    const objectUrl = URL.createObjectURL(file);
    setPreview(objectUrl);
  };

  useEffect(() => {
    return () => {
      if (preview) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  const validateForm = () => {
    if (!roomData.roomNumber.trim()) return "Room number is required";
    if (!roomData.name.trim()) return "Room name is required";
    if (!roomData.price || roomData.price <= 0)
      return "Price must be greater than 0";
    if (!roomData.capacity || roomData.capacity <= 0)
      return "Capacity must be valid";
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const error = validateForm();
    if (error) {
      setMessage({ type: "danger", text: error });
      return;
    }

    try {
      setLoading(true);

      const formData = new FormData();

      Object.entries(roomData).forEach(([key, value]) => {
        formData.append(key, value);
      });

      // TODO: Replace with API call
      // await axios.post("/api/rooms", formData);

      console.log("Submitted Room:", Object.fromEntries(formData));

      setMessage({ type: "success", text: "Room added successfully!" });
      setRoomData(initialState);
      setPreview(null);
    } catch (err) {
      setMessage({ type: "danger", text: "Something went wrong" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main p-4">
        <h2 className="mb-4">Add New Room</h2>

        {message && (
          <div className={`alert alert-${message.type}`}>
            {message.text}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="row">
            <div className="col-md-4 mb-3">
              <label className="form-label">Room Number *</label>
              <input
                type="text"
                name="roomNumber"
                value={roomData.roomNumber}
                onChange={handleChange}
                className="form-control"
              />
            </div>

            <div className="col-md-4 mb-3">
              <label className="form-label">Room Name *</label>
              <input
                type="text"
                name="name"
                value={roomData.name}
                onChange={handleChange}
                className="form-control"
              />
            </div>

            <div className="col-md-4 mb-3">
              <label className="form-label">Room Type</label>
              <select
                name="type"
                value={roomData.type}
                onChange={handleChange}
                className="form-select"
              >
                <option value="Single">Single</option>
                <option value="Double">Double</option>
                <option value="Deluxe">Deluxe</option>
                <option value="Suite">Suite</option>
              </select>
            </div>

            <div className="col-md-4 mb-3">
              <label className="form-label">Price (₹) *</label>
              <input
                type="number"
                name="price"
                value={roomData.price}
                onChange={handleChange}
                className="form-control"
              />
            </div>

            <div className="col-md-4 mb-3">
              <label className="form-label">Capacity</label>
              <input
                type="number"
                name="capacity"
                value={roomData.capacity}
                onChange={handleChange}
                className="form-control"
              />
            </div>

            <div className="col-md-4 mb-3">
              <label className="form-label">Status</label>
              <select
                name="status"
                value={roomData.status}
                onChange={handleChange}
                className="form-select"
              >
                <option value="Available">Available</option>
                <option value="Booked">Booked</option>
                <option value="Maintenance">Maintenance</option>
              </select>
            </div>
          </div>

          <div className="mb-3">
            <label className="form-label">Description</label>
            <textarea
              name="description"
              value={roomData.description}
              onChange={handleChange}
              className="form-control"
              rows={3}
            />
          </div>

          <div className="mb-3">
            <label className="form-label">Room Image</label>
            <input
              type="file"
              onChange={handleImageChange}
              className="form-control"
              accept="image/*"
            />
          </div>

          {preview && (
            <div className="mb-3">
              <img
                src={preview}
                alt="preview"
                style={{ width: 200, borderRadius: 10 }}
              />
            </div>
          )}

          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? "Adding..." : "Add Room"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddRoom;