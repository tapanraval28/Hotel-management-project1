import React, { useEffect, useState } from "react";
import AdminSidebar from "../../components/AdminSidebar";
import BookingChart from "../../components/BookingChart";
import { FaBed, FaCalendarCheck, FaUsers } from "react-icons/fa";

function AdminDashboard() {
  const [stats, setStats] = useState({
    totalRooms: 0,
    totalBookings: 0,
    totalUsers: 0,
    loading: true,
  });

  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchStats = async () => {
      try {
        setStats((prev) => ({ ...prev, loading: true }));

        // Replace later with real API
        // const res = await axios.get("/api/admin/stats");

        const mockData = {
          totalRooms: 12,
          totalBookings: 8,
          totalUsers: 5,
        };

        setStats({
          ...mockData,
          loading: false,
        });
      } catch (err) {
        setError("Failed to load dashboard data");
        setStats((prev) => ({ ...prev, loading: false }));
      }
    };

    fetchStats();
  }, []);

  return (
    <div className="admin-layout">
      <AdminSidebar />

      <div className="admin-main p-4">
        <h2 className="mb-4">Admin Dashboard</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        {stats.loading ? (
          <div className="text-center py-5">Loading dashboard...</div>
        ) : (
          <>
            <div className="row">
              {/* Total Rooms */}
              <div className="col-md-4 mb-4">
                <div className="card text-white bg-primary shadow border-0">
                  <div className="card-body text-center">
                    <FaBed size={35} />
                    <h5 className="mt-3">Total Rooms</h5>
                    <h3>{stats.totalRooms}</h3>
                  </div>
                </div>
              </div>

              {/* Total Bookings */}
              <div className="col-md-4 mb-4">
                <div className="card text-white bg-success shadow border-0">
                  <div className="card-body text-center">
                    <FaCalendarCheck size={35} />
                    <h5 className="mt-3">Total Bookings</h5>
                    <h3>{stats.totalBookings}</h3>
                  </div>
                </div>
              </div>

              {/* Total Users */}
              <div className="col-md-4 mb-4">
                <div className="card text-dark bg-warning shadow border-0">
                  <div className="card-body text-center">
                    <FaUsers size={35} />
                    <h5 className="mt-3">Total Users</h5>
                    <h3>{stats.totalUsers}</h3>
                  </div>
                </div>
              </div>
            </div>

            {/* Chart Section */}
            <div className="card shadow mt-4 border-0">
              <div className="card-body">
                <h5 className="mb-3">Booking Overview</h5>
                <BookingChart />
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default AdminDashboard;