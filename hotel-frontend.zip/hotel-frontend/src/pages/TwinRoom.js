import React from "react";
import { Link } from "react-router-dom";

function TwinRoom() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Twin Room
      </h2>

      <div className="row">

        <div className="col-md-6">

          <img
          src="https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf"
          className="img-fluid rounded shadow"
          alt="twin room"
          />

        </div>

        <div className="col-md-6">

          <h4 className="text-primary">
            Price: ₹2800 / Night
          </h4>

          <p>
          Our Twin Room features two separate beds and is ideal
          for friends or colleagues traveling together.
          Enjoy a comfortable stay with modern amenities.
          </p>

          <h5 className="mt-3">Room Facilities</h5>

          <ul>
            <li>Two Comfortable Single Beds</li>
            <li>Free High-Speed WiFi</li>
            <li>Air Conditioning</li>
            <li>Smart TV</li>
            <li>Study Desk</li>
            <li>Private Bathroom</li>
            <li>24/7 Room Service</li>
          </ul>

          <Link to="/booking" className="btn btn-primary btn-lg mt-3">
            Book Now
          </Link>

        </div>

      </div>

    </div>

  );
}

export default TwinRoom;