import React from "react";

function RoomDetails() {
  return (

    <div className="container mt-5">

      <h2 className="text-center mb-4">
        Deluxe Room Details
      </h2>

      <div className="row">

        <div className="col-md-6">

          <img
          src="https://images.unsplash.com/photo-1582719508461-905c673771fd"
          className="img-fluid rounded shadow"
          alt="room"
          />

          {/* Small Room Gallery */}

          <div className="row mt-3">

            <div className="col-4">
              <img
              src="https://images.unsplash.com/photo-1560448204-e02f11c3d0e2"
              className="img-fluid rounded"
              alt="room"
              />
            </div>

            <div className="col-4">
              <img
              src="https://images.unsplash.com/photo-1505693416388-ac5ce068fe85"
              className="img-fluid rounded"
              alt="room"
              />
            </div>

            <div className="col-4">
              <img
              src="https://images.unsplash.com/photo-1590490360182-c33d57733427"
              className="img-fluid rounded"
              alt="room"
              />
            </div>

          </div>

        </div>

        <div className="col-md-6">

          <h4>Room Description</h4>

          <p>
          Our Deluxe Rooms are designed to provide maximum comfort
          and luxury for guests. The room includes elegant interiors,
          modern furniture, and premium amenities to make your stay
          relaxing and memorable.
          </p>

          <p>
          Perfect for couples and business travelers looking for
          a stylish and comfortable stay experience.
          </p>

          <h5 className="mt-3">Facilities</h5>

          <ul>
            <li>King Size Bed</li>
            <li>Free High-Speed WiFi</li>
            <li>Air Conditioning</li>
            <li>Smart TV</li>
            <li>Mini Refrigerator</li>
            <li>Room Service</li>
            <li>Luxury Bathroom</li>
            <li>24/7 Customer Support</li>
          </ul>

          <h4 className="mt-3 text-primary">
            Price: ₹3500 / Night
          </h4>

          <button className="btn btn-primary btn-lg mt-3">
            Book This Room
          </button>

        </div>

      </div>

    </div>

  );
}

export default RoomDetails;